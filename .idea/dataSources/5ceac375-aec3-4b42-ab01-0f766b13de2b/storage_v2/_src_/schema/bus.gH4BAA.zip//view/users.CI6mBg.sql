CREATE DEFINER = admin@`%` VIEW users AS
SELECT `hu`.`id`                        AS `user_id`,
       `hu`.`name`                      AS `user`,
       `hu`.`signup_date`               AS `signup_date`,
       `hc`.`name`                      AS `country`,
       `tu`.`dates`                     AS `dates`,
       `tu`.`first_date`                AS `first_date`,
       `tu`.`last_date`                 AS `last_date`,
       `tu`.`active_games`              AS `active_games`,
       `tu`.`middle_games_daily`        AS `middle_games_daily`,
       `tu`.`active_game_types`         AS `active_game_types`,
       `tu`.`middle_game_types_daily`   AS `middle_game_types_daily`,
       `tu`.`transactions`              AS `transactions`,
       `tu`.`middle_transactions_daily` AS `middle_transactions_daily`,
       `tu`.`deposit`                   AS `deposit`,
       `tu`.`middle_deposit_daily`      AS `middle_deposit_daily`,
       `tu`.`deposits`                  AS `deposits`,
       `tu`.`middle_deposits_daily`     AS `middle_deposits_daily`,
       `tu`.`withdrawal`                AS `withdrawal`,
       `tu`.`middle_withdrawal_daily`   AS `middle_withdrawal_daily`,
       `tu`.`withdrawals`               AS `withdrawals`,
       `tu`.`middle_withdrawals_daily`  AS `middle_withdrawals_daily`,
       `tu`.`duration`                  AS `duration`,
       `tu`.`middle_duration_daily`     AS `middle_duration_daily`,
       `hu`.`created_at`                AS `created_at`,
       `hu`.`updated_at`                AS `updated_at`
FROM ((`vault`.`h_users` `hu` JOIN `vault`.`h_countries` `hc`
        ON ((`hu`.`country_id` = `hc`.`id`))) LEFT JOIN `bus`.`total_users` `tu`
        ON ((`hu`.`id` = `tu`.`user_id`)));

-- comment on column users.user_id not supported: User ID -int

-- comment on column users.user not supported: User Name -varchar(150)

-- comment on column users.signup_date not supported: Sign up date -date

-- comment on column users.country not supported: Country Name -varchar(150)

-- comment on column users.dates not supported: Number of dates

-- comment on column users.first_date not supported: First date

-- comment on column users.last_date not supported: Last date

-- comment on column users.active_games not supported: Number of active games

-- comment on column users.middle_games_daily not supported: Middle games daily

-- comment on column users.active_game_types not supported: Number of active game types

-- comment on column users.middle_game_types_daily not supported: Middle game types daily

-- comment on column users.transactions not supported: Number of transactions

-- comment on column users.middle_transactions_daily not supported: Middle transactions daily

-- comment on column users.deposit not supported: Deposit Amount

-- comment on column users.middle_deposit_daily not supported: Middle deposit daily

-- comment on column users.deposits not supported: Number of Deposits

-- comment on column users.middle_deposits_daily not supported: Middle deposits daily

-- comment on column users.withdrawal not supported: Withdrawal Amount

-- comment on column users.middle_withdrawal_daily not supported: Middle withdrawal daily

-- comment on column users.withdrawals not supported: Number of Withdrawals

-- comment on column users.middle_withdrawals_daily not supported: Middle withdrawals daily

-- comment on column users.duration not supported: Duration

-- comment on column users.middle_duration_daily not supported: Middle duration daily

-- comment on column users.created_at not supported: Created -datetime(6)

-- comment on column users.updated_at not supported: Updated -datetime(6)

