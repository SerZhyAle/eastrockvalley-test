CREATE DEFINER = admin@`%` VIEW games_users_dates AS
SELECT `hg`.`id`          AS `game_id`,
       `hgt`.`name`       AS `game_type`,
       `hg`.`created_at`  AS `game_created_at`,
       `hu`.`id`          AS `user_id`,
       `hu`.`name`        AS `user_name`,
       `hu`.`created_at`  AS `user_created_at`,
       `hu`.`signup_date` AS `signup_date`,
       `lugd`.`play_date` AS `play_date`,
       `sugd`.`duration`  AS `duration`
FROM ((((`vault`.`l_users_games_date` `lugd` JOIN `vault`.`s_users_games_date` `sugd`
        ON ((`lugd`.`id` = `sugd`.`l_users_games_date_id`))) JOIN `vault`.`h_users` `hu`
        ON ((`hu`.`id` = `lugd`.`user_id`))) JOIN `vault`.`h_games` `hg`
        ON ((`hg`.`id` = `lugd`.`game_id`))) JOIN `vault`.`h_game_types` `hgt`
        ON ((`hgt`.`id` = `hg`.`type_id`)));

-- comment on column games_users_dates.game_id not supported: Game ID -int

-- comment on column games_users_dates.game_type not supported: GameType Name -varchar(50)

-- comment on column games_users_dates.game_created_at not supported: Created -datetime(6)

-- comment on column games_users_dates.user_id not supported: User ID -int

-- comment on column games_users_dates.user_name not supported: User Name -varchar(150)

-- comment on column games_users_dates.user_created_at not supported: Created -datetime(6)

-- comment on column games_users_dates.signup_date not supported: Sign up date -date

-- comment on column games_users_dates.play_date not supported: Play Date -date

-- comment on column games_users_dates.duration not supported: Duration -int

