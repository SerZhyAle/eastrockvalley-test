CREATE DEFINER = admin@`%` VIEW games AS
SELECT `g`.`id`                      AS `id`,
       `hgt`.`name`                  AS `type`,
       `g`.`created_at`              AS `created_at`,
       `t`.`game_id`                 AS `game_id`,
       `t`.`dates`                   AS `dates`,
       `t`.`first_date`              AS `first_date`,
       `t`.`last_date`               AS `last_date`,
       `t`.`active_users`            AS `active_users`,
       `t`.`middle_users_daily`      AS `middle_users_daily`,
       `t`.`active_countries`        AS `active_countries`,
       `t`.`middle_active_countries` AS `middle_active_countries`,
       `t`.`duration`                AS `duration`,
       `t`.`middle_duration_daily`   AS `middle_duration_daily`
FROM ((`vault`.`h_games` `g` JOIN `vault`.`h_game_types` `hgt`
        ON ((`g`.`type_id` = `hgt`.`id`))) LEFT JOIN `bus`.`total_games` `t`
        ON ((`g`.`id` = `t`.`game_id`)));

-- comment on column games.id not supported: Game ID -int

-- comment on column games.type not supported: GameType Name -varchar(50)

-- comment on column games.created_at not supported: Created -datetime(6)

-- comment on column games.game_id not supported: Game ID

-- comment on column games.dates not supported: Number of dates

-- comment on column games.first_date not supported: First date

-- comment on column games.last_date not supported: Last date

-- comment on column games.active_users not supported: Number of active users

-- comment on column games.middle_users_daily not supported: Middle users daily

-- comment on column games.active_countries not supported: Number of countries

-- comment on column games.middle_active_countries not supported: Middle Number of countries daily

-- comment on column games.duration not supported: Duration

-- comment on column games.middle_duration_daily not supported: Middle duration daily

