CREATE DEFINER = admin@`%` VIEW payments AS
SELECT `p`.`transaction_id`   AS `transaction_id`,
       `p`.`user_id`          AS `user_id`,
       `p`.`amount`           AS `amount`,
       `p`.`transaction_date` AS `transaction_date`,
       `p`.`type`             AS `type`,
       `p`.`created_at`       AS `created_at`,
       `p`.`updated_at`       AS `updated_at`,
       `hu`.`name`            AS `user`,
       `hu`.`signup_date`     AS `signup_date`,
       `hc`.`name`            AS `country`
FROM ((`vault`.`payments` `p` JOIN `vault`.`h_users` `hu`
        ON ((`p`.`user_id` = `hu`.`id`))) JOIN `vault`.`h_countries` `hc`
        ON ((`hu`.`country_id` = `hc`.`id`)));

-- comment on column payments.transaction_id not supported: TransactionID -bigint

-- comment on column payments.user_id not supported: UserID -int

-- comment on column payments.amount not supported: Amount -dec(13,2)

-- comment on column payments.transaction_date not supported: TransactionDate --date

-- comment on column payments.type not supported: Type --enum

-- comment on column payments.created_at not supported: Created -datetime(6)

-- comment on column payments.updated_at not supported: Updated -datetime(6)

-- comment on column payments.user not supported: User Name -varchar(150)

-- comment on column payments.signup_date not supported: Sign up date -date

-- comment on column payments.country not supported: Country Name -varchar(150)

