CREATE
    DEFINER = admin@`%` PROCEDURE service_calendar_dates_population()
BEGIN

    SET @special = NULL;
    SET @is_public_holiday = NULL;
    SET @day_of_period = 1;

    SET @day_cursor = '2019-12-31';
    SET @quarter = 4; -- for '2019.12.31'
    SET @quarter_was = 4; -- for '2019.12.31'
    SET @number_of_calendar_week = 53; -- for '2019.12.31'
    SET @day_cursor_end = '2036-12-31';
    SET @begin_of_period = '2019-10-01';

    SET @end_of_period = LAST_DAY(DATE_ADD(@begin_of_period, INTERVAL 3 MONTH));
    SET @day_num_since_2020 = 0,
        @week_num_since_2020 = 1,
        @month_num_since_2020 = 0,
        @quarter_num_since_2020 = 0,
        @year_num_since_2020 = 0,
        @day_of_period = 92;

    WHILE @day_cursor <= @day_cursor_end
        DO
            SET @week_day_number = DATE_FORMAT(@day_cursor, '%w');

            IF DATE_FORMAT(@day_cursor, '%y') IN (20, 24, 28, 32, 36, 40) THEN
                SET @days_in_the_year = 366;
            ELSE
                SET @days_in_the_year = 365;
            END IF;

            IF DAY(@day_cursor) = 1 THEN
                SET @month_num_since_2020 = @month_num_since_2020 + 1;
            END IF;

            IF MONTH(@day_cursor) = 1
                AND DAY(@day_cursor) = 1
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'New Year Day';
            ELSEIF MONTH(@day_cursor) = 5
                AND DAY(@day_cursor) = 1
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'May Day';
            ELSEIF MONTH(@day_cursor) = 12
                AND DAY(@day_cursor) = 25
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Christmas Day';
            ELSEIF MONTH(@day_cursor) = 12
                AND DAY(@day_cursor) = 26
            THEN
                SET @is_public_holiday = 1;
                SET @special = '2nd Day of Christmas';
                /*
            ELSEIF MONTH(@day_cursor) = 1
                AND DAY(@day_cursor) = 5
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Epiphany';
            ELSEIF MONTH(@day_cursor) = 4
                AND DAY(@day_cursor) = 6
                AND YEAR(@day_cursor) = 2023
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Maundy Thursday';
            ELSEIF MONTH(@day_cursor) = 4
                AND DAY(@day_cursor) = 7
                AND YEAR(@day_cursor) = 2023
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Good Friday';
            ELSEIF MONTH(@day_cursor) = 4
                AND DAY(@day_cursor) = 9
                AND YEAR(@day_cursor) = 2023
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Easter Sunday';
            ELSEIF MONTH(@day_cursor) = 4
                AND DAY(@day_cursor) = 10
                AND YEAR(@day_cursor) = 2023
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Easter Monday';
            ELSEIF MONTH(@day_cursor) = 5
                AND DAY(@day_cursor) = 5
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Prayer Day';
            ELSEIF MONTH(@day_cursor) = 5
                AND DAY(@day_cursor) = 18
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Ascension Day';
            ELSEIF MONTH(@day_cursor) = 5
                AND DAY(@day_cursor) = 28
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Whit Sunday';
            ELSEIF MONTH(@day_cursor) = 5
                AND DAY(@day_cursor) = 29
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Whit Monday';
            ELSEIF MONTH(@day_cursor) = 6
                AND DAY(@day_cursor) = 6
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'National Day';
            ELSEIF MONTH(@day_cursor) = 6
                AND DAY(@day_cursor) = 24
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'Midsummer Day';
            ELSEIF MONTH(@day_cursor) = 11
                AND DAY(@day_cursor) = 4
            THEN
                SET @is_public_holiday = 1;
                SET @special = 'All Saints Day';

                 */
            ELSE
                SET @is_public_holiday = 0;
                SET @special = NULL;
            END IF;

            SET @is_weekend = (IF(@week_day_number IN (6, 0), 1, 0));

            IF (@is_public_holiday + @is_weekend) = 0
            THEN
                SET @is_working_day = 1;
            ELSE
                SET @is_working_day = 0;
            END IF;

            IF MONTH(@day_cursor) IN (4, 7, 10, 1)
                AND DAY(@day_cursor) = 1 THEN

                SET @quarter = @quarter + 1,
                    @begin_of_period = @day_cursor,
                    @end_of_period = LAST_DAY(DATE_ADD(@begin_of_period, INTERVAL 3 MONTH));
            END IF;

            IF MONTH(@day_cursor) = 1
                AND DAY(@day_cursor) = 1 THEN

                SET @quarter = 1,
                    @year_num_since_2020 = @year_num_since_2020 + 1;
            END IF;

            IF @quarter <> @quarter_was THEN
                SET @day_of_period = 1,
                    @quarter_was = @quarter,
                    @quarter_num_since_2020 = @quarter_num_since_2020 + 1;
            END IF;

            IF @week_day_number = 1 THEN

                IF MONTH(@day_cursor) = 1
                    AND @number_of_calendar_week > 50 THEN

                    SET @number_of_calendar_week = 1;
                ELSE
                    SET @number_of_calendar_week = @number_of_calendar_week + 1;
                END IF;
            END IF;

            IF @week_day_number = 1 THEN
                SET @week_num_since_2020 = @week_num_since_2020 + 1;
            END IF;

            SET @month_cursor = EXTRACT(MONTH FROM @day_cursor);
            SET @day_of_cursor = EXTRACT(DAY FROM @day_cursor);
            SET @tomorrow = EXTRACT(DAY FROM DATE_ADD(@day_cursor, INTERVAL 1 DAY));

            INSERT INTO calendar_dates_swap(date,
                                            date8,
                                            date_ymd,
                                            date_dmy,
                                            date_ddmm,
                                            date_mdy,
                                            date_dmmmy,
                                            date_dmmmmy,
                                            day_of_week,
                                            day_of_week_char,
                                            is_weekday,
                                            is_weekend,
                                            day_name,
                                            day_name3,
                                            day_of_month,
                                            day_of_month2,
                                            day_of_month_char,
                                            day_of_quarter,
                                            day_of_year,
                                            week,
                                            week2,
                                            week_finance,
                                            year_week,
                                            month,
                                            month2,
                                            month_name,
                                            month_name3,
                                            quarter,
                                            year_quarter,
                                            year,
                                            year2,
                                            year2c,
                                            days_in_year,
                                            zodiac,
                                            is_public_holiday,
                                            fullname,
                                            is_last_day_of_week,
                                            is_last_day_of_month,
                                            is_last_day_of_quarter,
                                            is_last_day_of_year,
                                            week_begin,
                                            week_end,
                                            month_begin,
                                            month_end,
                                            quarter_begin,
                                            quarter_end,
                                            year_begin,
                                            year_end,
                                            week_before,
                                            week_after,
                                            month_before,
                                            month_after,
                                            quarter_before,
                                            quarter_after,
                                            year_before,
                                            year_after,
                                            special_date,
                                            is_working_day,
                                            day_num_since_2020,
                                            week_num_since_2020,
                                            month_num_since_2020,
                                            quarter_num_since_2020,
                                            year_num_since_2020,
                                            year_month2,
                                            next_date,
                                            prev_date,
                                            date_mmdd,
                                            week_fullname)
            VALUES (@day_cursor,
                    DATE_FORMAT(@day_cursor, '%Y%m%d'),
                    DATE_FORMAT(@day_cursor, '%Y-%m-%d'),
                    DATE_FORMAT(@day_cursor, '%d.%m.%Y'),
                    DATE_FORMAT(@day_cursor, '%d.%m'),
                    DATE_FORMAT(@day_cursor, '%m/%d/%Y'),
                    DATE_FORMAT(@day_cursor, '%d %b %Y'),
                    DATE_FORMAT(@day_cursor, '%d %M %Y'),
                    @week_day_number,
                    CONCAT((@week_day_number + 1), CASE
                                                       WHEN (@week_day_number + 1) > 3 THEN 'th'
                                                       WHEN (@week_day_number + 1) = 1 THEN 'st'
                                                       WHEN (@week_day_number + 1) = 2 THEN 'nd'
                                                       ELSE 'rd' END),
                    IF(@week_day_number IN (6, 0), FALSE, TRUE),
                    @is_weekend,
                    DATE_FORMAT(@day_cursor, '%W'),
                    DATE_FORMAT(@day_cursor, '%a'),
                    EXTRACT(DAY FROM @day_cursor),
                    DATE_FORMAT(@day_cursor, '%d'),
                    DATE_FORMAT(@day_cursor, '%D'),
                    @day_of_period,
                    DATE_FORMAT(@day_cursor, '%j'),
                    @number_of_calendar_week,
                    RIGHT(CONCAT('0', WEEK(@day_cursor, 1)), 2),
                    DATE_FORMAT(@day_cursor, '%v'),
                    CONCAT(EXTRACT(YEAR FROM @day_cursor), '/', RIGHT(CONCAT('0', @number_of_calendar_week), 2)),
                    @month_cursor,
                    DATE_FORMAT(@day_cursor, '%m'),
                    DATE_FORMAT(@day_cursor, '%M'),
                    DATE_FORMAT(@day_cursor, '%b'),
                    @quarter,
                    CONCAT(EXTRACT(YEAR FROM @day_cursor), ' ', @quarter),
                    EXTRACT(YEAR FROM @day_cursor),
                    DATE_FORMAT(@day_cursor, '%y'),
                    DATE_FORMAT(@day_cursor, '%y'),
                    @days_in_the_year,
                    CASE
                        WHEN (@day_of_cursor >= 21 AND @month_cursor = 3
                            OR @day_of_cursor <= 19 AND @month_cursor = 4)
                            THEN '03 Aries'
                        WHEN (@day_of_cursor >= 20 AND @month_cursor = 4
                            OR @day_of_cursor <= 20 AND @month_cursor = 5)
                            THEN '04 Taurus'
                        WHEN (@day_of_cursor >= 21 AND @month_cursor = 5
                            OR @day_of_cursor <= 20 AND @month_cursor = 6)
                            THEN '05 Gemini'
                        WHEN (@day_of_cursor >= 21 AND @month_cursor = 6
                            OR @day_of_cursor <= 22 AND @month_cursor = 7)
                            THEN '06 Cancer'
                        WHEN (@day_of_cursor >= 23 AND @month_cursor = 7
                            OR @day_of_cursor <= 22 AND @month_cursor = 8)
                            THEN '07 Leo'
                        WHEN (@day_of_cursor >= 23 AND @month_cursor = 8
                            OR @day_of_cursor <= 22 AND @month_cursor = 9)
                            THEN '08 Virgo'
                        WHEN (@day_of_cursor >= 23 AND @month_cursor = 9
                            OR @day_of_cursor <= 22 AND @month_cursor = 10)
                            THEN '09 Libra'
                        WHEN (@day_of_cursor >= 23 AND @month_cursor = 10
                            OR @day_of_cursor <= 21 AND @month_cursor = 11)
                            THEN '10 Scorpio'
                        WHEN (@day_of_cursor >= 22 AND @month_cursor = 11
                            OR @day_of_cursor <= 21 AND @month_cursor = 12)
                            THEN '11 Sagittarius'
                        WHEN (@day_of_cursor >= 22 AND @month_cursor = 12
                            OR @day_of_cursor <= 20 AND @month_cursor = 1)
                            THEN '12 Capricorn'
                        WHEN (@day_of_cursor >= 21 AND @month_cursor = 1
                            OR @day_of_cursor <= 18 AND @month_cursor = 2)
                            THEN '01 Aquarius'
                        ELSE '02 Pisces'
                        END,
                    @is_public_holiday,
                    DATE_FORMAT(@day_cursor, '%D %M %Y (%W)'),
                    IF(@week_day_number = 0, 1, 0),
                    IF(@tomorrow = 1, 1, 0),
                    IF(EXTRACT(MONTH FROM DATE_ADD(@day_cursor, INTERVAL 1 DAY)) IN (1, 4, 7, 10)
                           AND @tomorrow = 1, 1, 0),
                    IF(EXTRACT(MONTH FROM DATE_ADD(@day_cursor, INTERVAL 1 DAY)) = 1
                           AND @tomorrow = 1, 1, 0),
                    DATE_ADD(@day_cursor, INTERVAL IF(@week_day_number = 0, -6, -@week_day_number + 1) DAY),
                    DATE_ADD(@day_cursor, INTERVAL IF(@week_day_number = 0, 0, 7 - @week_day_number) DAY),
                    DATE_FORMAT(@day_cursor, '%Y-%m-01'),
                    LAST_DAY(@day_cursor),
                    @begin_of_period,
                    @end_of_period,
                    MAKEDATE(YEAR(@day_cursor), 1),
                    DATE_ADD(MAKEDATE(YEAR(@day_cursor) + 1, 1), INTERVAL -1 DAY),
                    DATE_ADD(@day_cursor, INTERVAL -7 DAY),
                    DATE_ADD(@day_cursor, INTERVAL 7 DAY),
                    DATE_ADD(@day_cursor, INTERVAL -1 MONTH),
                    DATE_ADD(@day_cursor, INTERVAL 1 MONTH),
                    DATE_ADD(@day_cursor, INTERVAL -3 MONTH),
                    DATE_ADD(@day_cursor, INTERVAL 3 MONTH),
                    DATE_ADD(@day_cursor, INTERVAL -1 YEAR),
                    DATE_ADD(@day_cursor, INTERVAL 1 YEAR),
                    @special,
                    @is_working_day,
                    @day_num_since_2020,
                    @week_num_since_2020,
                    @month_num_since_2020,
                    @quarter_num_since_2020,
                    @year_num_since_2020,
                    CONCAT(EXTRACT(YEAR FROM @day_cursor), '-', DATE_FORMAT(@day_cursor, '%m')),
                    DATE_ADD(@day_cursor, INTERVAL 1 DAY),
                    DATE_ADD(@day_cursor, INTERVAL -1 DAY),
                    DATE_FORMAT(@day_cursor, '%m-%d'),
                    CONCAT(DATE_ADD(@day_cursor, INTERVAL IF(@week_day_number = 0, -6, -@week_day_number + 1)
                                    DAY), ' - ',
                           DATE_ADD(@day_cursor, INTERVAL IF(@week_day_number = 0, 0, 7 - @week_day_number)
                                    DAY)));

            SET @day_cursor = DATE_ADD(@day_cursor, INTERVAL 1 DAY);
            SET @day_of_period = @day_of_period + 1;
            SET @day_num_since_2020 = @day_num_since_2020 + 1;

        END WHILE;
    START TRANSACTION ;
    DROP TABLE IF EXISTS calendar_dates;
    RENAME TABLE calendar_dates_swap TO calendar_dates;
    COMMIT;

END;

