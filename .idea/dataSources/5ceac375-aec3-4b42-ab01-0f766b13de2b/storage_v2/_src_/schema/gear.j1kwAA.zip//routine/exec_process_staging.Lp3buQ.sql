CREATE
    DEFINER = admin@`%` PROCEDURE exec_process_staging()
BEGIN
    -- import
    CALL gear.exec_process_users();
    CALL gear.exec_process_games();
    CALL gear.exec_link_users_and_games();
    CALL gear.exec_process_payments();

END;

