CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_daily_payments(IN in_date date)
BEGIN
    -- call gear.aggregate_daily_payments(NULL);

    SET @in_date = in_date;

    IF @in_date IS NULL THEN
        SELECT MIN(u.signup_date) AS min_date
        FROM vault.h_users u
        INTO @in_date;

        SET @this_is_full_reload = 1;
    ELSE
        SET @this_is_full_reload = 0;
    END IF;

    DROP TABLE IF EXISTS gear.temp_daily_payments;
    CREATE TABLE gear.temp_daily_payments
    SELECT p.transaction_date                          AS date,
           p.type                                      AS type,
           COUNT(DISTINCT transaction_id)              AS transactions,
           COUNT(DISTINCT u.id)                        AS active_users,
           COUNT(DISTINCT u.country_id)                AS active_countries,
           SUM(IF(p.type = 'Deposit', 1, 0))           AS deposits,
           SUM(IF(p.type = 'Deposit', p.amount, 0))    AS deposit,
           SUM(IF(p.type = 'Withdrawal', 1, 0))        AS withdrawals,
           SUM(IF(p.type = 'Withdrawal', p.amount, 0)) AS withdrawal
    FROM vault.h_users u
        JOIN vault.payments p
            ON p.user_id = u.id
    WHERE p.transaction_date >= @in_date
    GROUP BY p.transaction_date, p.type;

-- _________________________________________________________________ --
    DROP TABLE IF EXISTS gear.swap_daily_payments;
    CREATE TABLE gear.swap_daily_payments LIKE bus.daily_payments;

    INSERT INTO gear.swap_daily_payments (date, type, active_users, active_countries, transactions, deposit, deposits, withdrawal, withdrawals)
    SELECT cp.date,
           cp.type,
           SUM(cp.active_users)     AS active_users,
           SUM(cp.active_countries) AS active_countries,
           SUM(cp.transactions)     AS transactions,
           SUM(cp.deposit)          AS deposit,
           SUM(cp.deposits)         AS deposits,
           SUM(cp.withdrawal)       AS withdrawal,
           SUM(cp.withdrawals)      AS withdrawals
    FROM gear.temp_daily_payments AS cp
    WHERE cp.date >= @in_date
      AND cp.date <= CURRENT_DATE
    GROUP BY cp.date, cp.type;

    IF @this_is_full_reload = 1 THEN
        START TRANSACTION;

        DROP TABLE IF EXISTS bus.daily_payments;
        RENAME TABLE gear.swap_daily_payments TO bus.daily_payments;
        COMMIT;

    ELSE -- only new
        REPLACE INTO bus.daily_payments (date, type, active_users, active_countries, transactions, deposit, deposits, withdrawal, withdrawals)
        SELECT date, type, active_users, active_countries, transactions, deposit, deposits, withdrawal, withdrawals
        FROM gear.swap_daily_payments;

        DROP TABLE gear.swap_daily_payments;
    END IF;

-- don't need to run often
  --  CALL gear.aggregate_total_payments();

END;

