CREATE
    DEFINER = admin@`%` PROCEDURE exec_process_users()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS temp_in_users;

    SET @processed_users = 0;

    CREATE TEMPORARY TABLE temp_in_users
    SELECT DISTINCT userid                              AS user_id,
                    username                            AS user_name,
                    STR_TO_DATE(signupdate, '%d/%m/%Y') AS signup_date,
                    country,
                    MAX(imported_at)                    AS imported_at
    FROM staging.users
    WHERE userid <> 'UserID'
    GROUP BY userid,
             username,
             STR_TO_DATE(signupdate, '%d/%m/%Y'),
             country;

    CREATE INDEX index_temp_in_users_user_id
        ON temp_in_users (user_id);

    INSERT INTO vault.h_countries(name)
    SELECT DISTINCT country
    FROM temp_in_users new
        LEFT JOIN vault.h_countries old
            ON old.name = new.country
    WHERE old.name IS NULL;

    DROP TEMPORARY TABLE IF EXISTS temp_recently_changed;
    CREATE TEMPORARY TABLE temp_recently_changed LIKE gear.recent_changes;
    #______________________________________________________________________________________

    START TRANSACTION;

-- users
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'user', 'changed', new.user_id
    FROM temp_in_users AS new
        JOIN vault.h_users old
            ON old.id = new.user_id
        JOIN vault.h_countries AS countries
            ON countries.name = new.country
    WHERE (old.name <> new.user_name OR
           old.signup_date <> new.signup_date OR
           old.country_id <> countries.id);

    UPDATE vault.h_users old
        JOIN temp_recently_changed AS r_ch
        ON old.id = r_ch.element_id
        JOIN temp_in_users AS new
        ON old.id = new.user_id
        JOIN vault.h_countries AS countries
        ON countries.name = new.country
    SET old.name        = new.user_name,
        old.signup_date = new.signup_date,
        old.country_id  = countries.id
    WHERE (old.name <> new.user_name OR
           old.signup_date <> new.signup_date OR
           old.country_id <> countries.id);
    SET @processed_users = @processed_users + ROW_COUNT();

-- ins
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'user', 'new', new.user_id
    FROM temp_in_users AS new
        LEFT JOIN vault.h_users AS old
            ON old.id = new.user_id
    WHERE old.id IS NULL;

    INSERT INTO vault.h_users(id,
                              name,
                              signup_date,
                              country_id)
    SELECT new.user_id,
           new.user_name,
           new.signup_date,
           c.id AS country_id
    FROM temp_recently_changed AS r_ch
        JOIN temp_in_users AS new
            ON r_ch.data_status = 'new'
            AND new.user_id = r_ch.element_id
        JOIN vault.h_countries AS c
            ON c.name = new.country;
    SET @processed_users = @processed_users + ROW_COUNT();

--
    INSERT INTO bulk.processed_users(user_id, user_name, signup_date, country, imported_at)
    SELECT user_id, user_name, signup_date, country, imported_at
    FROM temp_in_users;

    TRUNCATE TABLE staging.users;
    COMMIT;

    SELECT MAX(imported_at) AS imported_at
    FROM temp_in_users tig
    INTO @imported_at;

    DROP TEMPORARY TABLE temp_in_users;

    INSERT gear.process_staging_logs(table_name, processed_count, imported_at)
        VALUE ('users', @processed_users, @imported_at);

    INSERT gear.recent_changes(data_type, element_id, data_status)
    SELECT data_type, element_id, data_status
    FROM temp_recently_changed;

    DROP TEMPORARY TABLE temp_recently_changed;
END;

