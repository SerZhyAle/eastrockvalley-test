CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_total_users()
BEGIN

    DROP TABLE IF EXISTS gear.temp_total_users_games;
    CREATE TABLE gear.temp_total_users_games
    SELECT u.id                         AS user_id,
           COUNT(DISTINCT lugd.game_id) AS active_games,
           COUNT(DISTINCT g.type_id)    AS active_game_types
    FROM vault.h_users u
        JOIN vault.l_users_games_date lugd
            ON u.id = lugd.user_id
        JOIN vault.h_games g
            ON g.id = lugd.game_id
    GROUP BY u.id;

    DROP TABLE IF EXISTS gear.temp_total_users;
    CREATE TABLE gear.temp_total_users
    SELECT user_id,
           user,
           COUNT(DISTINCT date)                     AS dates,
           MIN(date)                                AS first_date,
           MAX(date)                                AS last_date,
           SUM(transactions)                        AS transactions,
           SUM(transactions) / COUNT(DISTINCT date) AS middle_transactions_daily,
           SUM(deposit)                             AS deposit,
           SUM(deposit) / COUNT(DISTINCT date)      AS middle_deposit_daily,
           SUM(deposits)                            AS deposits,
           SUM(deposits) / COUNT(DISTINCT date)     AS middle_deposits_daily,
           SUM(withdrawal)                          AS withdrawal,
           SUM(withdrawal) / COUNT(DISTINCT date)   AS middle_withdrawal_daily,
           SUM(withdrawals)                         AS withdrawals,
           SUM(withdrawals) / COUNT(DISTINCT date)  AS middle_withdrawals_daily,
           SUM(duration)                            AS duration,
           SUM(duration) / COUNT(DISTINCT date)     AS middle_duration_daily
    FROM bus.daily_users AS du
    WHERE user IS NOT NULL
    GROUP BY user_id, user;

    REPLACE INTO bus.total_users(user_id, user, dates, first_date, last_date, active_games, middle_games_daily,
                                 active_game_types, middle_game_types_daily, transactions,
                                 middle_transactions_daily, deposit, middle_deposit_daily, deposits, middle_deposits_daily,
                                 withdrawal, middle_withdrawal_daily, withdrawals, middle_withdrawals_daily, duration, middle_duration_daily)
    SELECT du.user_id,
           du.user,
           du.dates,
           du.first_date,
           du.last_date,
           g.active_games,
           g.active_games / du.dates      AS middle_games_daily,
           g.active_game_types,
           g.active_game_types / du.dates AS middle_game_types_daily,
           du.transactions,
           du.middle_transactions_daily,
           du.deposit,
           du.middle_deposit_daily,
           du.deposits,
           du.middle_deposits_daily,
           du.withdrawal,
           du.middle_withdrawal_daily,
           du.withdrawals,
           du.middle_withdrawals_daily,
           du.duration,
           du.middle_duration_daily
    FROM gear.temp_total_users AS du
        JOIN gear.temp_total_users_games AS g
            ON g.user_id = du.user_id;

END;

