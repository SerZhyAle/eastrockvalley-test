CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_total_payments()
BEGIN

-- is set for midnight_routine_aggregations

    DROP TABLE IF EXISTS gear.temp_total_users_payments;
    CREATE TABLE gear.temp_total_users_payments
    SELECT p.type,
           COUNT(DISTINCT p.user_id) AS active_users,
           COUNT(DISTINCT u.country_id)    AS active_countries
    FROM vault.payments p
    join     vault.h_users u
    on u.id = p.user_id
    GROUP BY p.type;

    DROP TABLE IF EXISTS gear.temp_total_payment;
    CREATE TABLE gear.temp_total_payment
    SELECT type,
           COUNT(DISTINCT date)                     AS dates,
           MIN(date)                                AS first_date,
           MAX(date)                                AS last_date,
           SUM(transactions)                        AS transactions,
           SUM(transactions) / COUNT(DISTINCT date) AS middle_transactions_daily,
           SUM(deposit)                             AS deposit,
           SUM(deposit) / COUNT(DISTINCT date)      AS middle_deposit_daily,
           SUM(deposits)                            AS deposits,
           SUM(deposits) / COUNT(DISTINCT date)     AS middle_deposits_daily,
           SUM(withdrawal)                          AS withdrawal,
           SUM(withdrawal) / COUNT(DISTINCT date)   AS middle_withdrawal_daily,
           SUM(withdrawals)                         AS withdrawals,
           SUM(withdrawals) / COUNT(DISTINCT date)  AS middle_withdrawals_daily
    FROM bus.daily_payments AS du
    GROUP BY type;

    REPLACE INTO bus.total_payments(type, dates, first_date, last_date, active_users, middle_users_daily, active_countries, middle_active_countries, transactions, middle_transactions_daily, deposit, middle_deposit_daily, deposits, middle_deposits_daily, withdrawal, middle_withdrawal_daily, withdrawals, middle_withdrawals_daily)
    SELECT du.type,
           du.dates,
           du.first_date,
           du.last_date,
           g.active_users,
           g.active_users / du.dates      AS middle_users_daily,
           g.active_countries,
           g.active_countries / du.dates AS middle_countries_daily,
           du.transactions,
           du.middle_transactions_daily,
           du.deposit,
           du.middle_deposit_daily,
           du.deposits,
           du.middle_deposits_daily,
           du.withdrawal,
           du.middle_withdrawal_daily,
           du.withdrawals,
           du.middle_withdrawals_daily
    FROM gear.temp_total_payment AS du
        JOIN gear.temp_total_users_payments AS g
            ON g.type = du.type;

END;

