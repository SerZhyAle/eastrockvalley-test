CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_daily_users(IN in_date date)
BEGIN
    -- call gear.aggregate_daily_users(NULL);

    SET @in_date = in_date;

    IF @in_date IS NULL THEN
        SELECT MIN(u.signup_date) AS min_date
        FROM vault.h_users u
        INTO @in_date;

        SET @this_is_full_reload = 1;
    ELSE
        SET @this_is_full_reload = 0;
    END IF;

    DROP TABLE IF EXISTS gear.temp_daily_users_ugd;
    CREATE TABLE gear.temp_daily_users_ugd
    SELECT lugd.play_date               AS date,
           u.id                         AS user_id,
           COUNT(DISTINCT lugd.game_id) AS active_games,
           COUNT(DISTINCT hgt.id)       AS active_game_types,
           SUM(sugd.duration)           AS duration
    FROM vault.h_users u
        JOIN vault.l_users_games_date lugd
            ON u.id = lugd.user_id
        JOIN vault.s_users_games_date sugd
            ON lugd.id = sugd.l_users_games_date_id
        JOIN vault.h_games hg
            ON hg.id = lugd.game_id
        JOIN vault.h_game_types hgt
            ON hgt.id = hg.type_id
    WHERE lugd.play_date >= @in_date
    GROUP BY lugd.play_date, u.id;

    DROP TABLE IF EXISTS gear.temp_daily_users_payments;
    CREATE TABLE gear.temp_daily_users_payments
    SELECT p.transaction_date                          AS date,
           u.id                                        AS user_id,
           COUNT(DISTINCT p.transaction_id)            AS transactions,
           SUM(IF(p.type = 'Deposit', 1, 0))           AS deposits,
           SUM(IF(p.type = 'Deposit', p.amount, 0))    AS deposit,
           SUM(IF(p.type = 'Withdrawal', 1, 0))        AS withdrawals,
           SUM(IF(p.type = 'Withdrawal', p.amount, 0)) AS withdrawal
    FROM vault.h_users u
        JOIN vault.payments p
            ON p.user_id = u.id
    WHERE p.transaction_date >= @in_date
    GROUP BY p.transaction_date, u.id;

-- _________________________________________________________________ --
    DROP TABLE IF EXISTS gear.swap_daily_users;
    CREATE TABLE gear.swap_daily_users LIKE bus.daily_users;

    INSERT INTO gear.swap_daily_users (date, user_id, user, active_games, active_game_types, transactions, deposit, deposits, withdrawal, withdrawals, duration)
    SELECT dates.date,
           u.id                        AS user_id,
           u.name                      AS user,
           SUM(cugd.active_games)      AS active_games,
           SUM(cugd.active_game_types) AS active_game_types,
           SUM(cp.transactions)        AS transactions,
           SUM(cp.deposit)             AS deposit,
           SUM(cp.deposits)            AS deposits,
           SUM(cp.withdrawal)          AS withdrawal,
           SUM(cp.withdrawals)         AS withdrawals,
           SUM(cugd.duration)          AS duration
    FROM vault.calendar_dates dates
        INNER JOIN vault.h_users u
        LEFT JOIN gear.temp_daily_users_ugd AS cugd
            ON cugd.date = dates.date AND cugd.user_id = u.id
        LEFT JOIN gear.temp_daily_users_payments AS cp
            ON cp.date = dates.date AND cp.user_id = u.id
    WHERE dates.date >= @in_date
      AND dates.date <= CURRENT_DATE
    GROUP BY dates.date, u.name;

    IF @this_is_full_reload = 1 THEN
        START TRANSACTION;

        DROP TABLE IF EXISTS bus.daily_users;
        RENAME TABLE gear.swap_daily_users TO bus.daily_users;
        COMMIT;

    ELSE -- only new
        REPLACE INTO bus.daily_users (date, user_id, user, active_games, active_game_types, transactions, deposit, deposits, withdrawal, withdrawals, duration)
        SELECT date,
               user_id,
               user,
               active_games,
               active_game_types,
               transactions,
               deposit,
               deposits,
               withdrawal,
               withdrawals,
               duration
        FROM gear.swap_daily_users;

        DROP TABLE gear.swap_daily_users;
    END IF;

    CALL gear.aggregate_total_users();

END;

