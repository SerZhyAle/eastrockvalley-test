CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_daily_countries(IN in_date date)
BEGIN
    -- call gear.aggregate_daily_countries(NULL);

    SET @in_date = in_date;

    IF @in_date IS NULL THEN
        SELECT MIN(u.signup_date) AS min_date
        FROM vault.h_users u
        INTO @in_date;

        SET @this_is_full_reload = 1;
    ELSE
        SET @this_is_full_reload = 0;
    END IF;

    DROP TABLE IF EXISTS gear.temp_daily_countries_users;
    CREATE TABLE gear.temp_daily_countries_users
    SELECT u.signup_date        AS date,
           c.id                 AS country_id,
           COUNT(DISTINCT u.id) AS sign_ups
    FROM vault.h_countries c
        JOIN vault.h_users u
            ON u.country_id = c.id
    WHERE u.signup_date >= @in_date
    GROUP BY u.signup_date, c.id;

    DROP TABLE IF EXISTS gear.temp_daily_countries_ugd;
    CREATE TABLE gear.temp_daily_countries_ugd
    SELECT lugd.play_date               AS date,
           c.id                         AS country_id,
           COUNT(DISTINCT u.id)         AS active_users,
           COUNT(DISTINCT lugd.game_id) AS active_games,
           SUM(sugd.duration)           AS duration
    FROM vault.h_countries c
        JOIN vault.h_users u
            ON u.country_id = c.id
        JOIN vault.l_users_games_date lugd
            ON u.id = lugd.user_id
        JOIN vault.s_users_games_date sugd
            ON lugd.id = sugd.l_users_games_date_id
    WHERE lugd.play_date >= @in_date
    GROUP BY lugd.play_date, c.id;

    DROP TABLE IF EXISTS gear.temp_daily_countries_payments;
    CREATE TABLE gear.temp_daily_countries_payments
    SELECT p.transaction_date                          AS date,
           c.id                                        AS country_id,
           COUNT(DISTINCT p.transaction_id)            AS transactions,
           SUM(IF(p.type = 'Deposit', 1, 0))           AS deposits,
           SUM(IF(p.type = 'Deposit', p.amount, 0))    AS deposit,
           SUM(IF(p.type = 'Withdrawal', 1, 0))        AS withdrawals,
           SUM(IF(p.type = 'Withdrawal', p.amount, 0)) AS withdrawal
    FROM vault.h_countries c
        JOIN vault.h_users u
            ON u.country_id = c.id
        JOIN vault.payments p
            ON p.user_id = u.id
    WHERE p.transaction_date >= @in_date
    GROUP BY p.transaction_date, c.id;

-- _________________________________________________________________ --
    DROP TABLE IF EXISTS gear.swap_daily_countries;
    CREATE TABLE gear.swap_daily_countries LIKE bus.daily_countries;

    INSERT INTO gear.swap_daily_countries (date, country_id, country, active_users, active_games, sign_ups, transactions, deposit, deposits, withdrawal, withdrawals, duration)
    SELECT dates.date,
           hc.id                  AS country_id,
           hc.name                AS country,
           SUM(cugd.active_users) AS active_users,
           SUM(cugd.active_games) AS active_games,
           SUM(cu.sign_ups)       AS sign_ups,
           SUM(cp.transactions)   AS transactions,
           SUM(cp.deposit)        AS deposit,
           SUM(cp.deposits)       AS deposits,
           SUM(cp.withdrawal)     AS withdrawal,
           SUM(cp.withdrawals)    AS withdrawals,
           SUM(cugd.duration)     AS duration
    FROM vault.calendar_dates dates
        INNER JOIN vault.h_countries hc
        LEFT JOIN gear.temp_daily_countries_users AS cu
            ON cu.date = dates.date AND cu.country_id = hc.id
        LEFT JOIN gear.temp_daily_countries_ugd AS cugd
            ON cugd.date = dates.date AND cugd.country_id = hc.id
        LEFT JOIN gear.temp_daily_countries_payments AS cp
            ON cp.date = dates.date AND cp.country_id = hc.id
    WHERE dates.date >= @in_date
      AND dates.date <= CURRENT_DATE
    GROUP BY dates.date, hc.name;

    IF @this_is_full_reload = 1 THEN
        START TRANSACTION;

        DROP TABLE IF EXISTS bus.daily_countries;
        RENAME TABLE gear.swap_daily_countries TO bus.daily_countries;
        COMMIT;

    ELSE -- only new
        REPLACE INTO bus.daily_countries (date, country_id, country, active_users, active_games, sign_ups, transactions, deposit, deposits, withdrawal, withdrawals, duration)
        SELECT date,
               country_id,
               country,
               active_users,
               active_games,
               sign_ups,
               transactions,
               deposit,
               deposits,
               withdrawal,
               withdrawals,
               duration
        FROM gear.swap_daily_countries;

        DROP TABLE gear.swap_daily_countries;
    END IF;

    CALL gear.aggregate_total_countries();

END;

