CREATE
    DEFINER = admin@`%` PROCEDURE calc_aggregations()
BEGIN

    DROP TEMPORARY TABLE IF EXISTS temp_changed_to_aggregate;

    START TRANSACTION ;

-- calculate min_date to process only new date(s)
    SELECT MIN(min_date) AS min_date
    FROM (SELECT MIN(u.signup_date) AS min_date
          FROM gear.recent_changes ch
              JOIN vault.h_users u
                  ON u.id = ch.element_id
          WHERE ch.data_type = 'user'
          UNION ALL
          SELECT MIN(p.transaction_date) AS min_date
          FROM gear.recent_changes ch
              JOIN vault.payments p
                  ON p.transaction_id = ch.element_id
          WHERE ch.data_type = 'payment'
          UNION ALL
          SELECT MIN(lugd.play_date) AS min_date
          FROM gear.recent_changes ch
              JOIN vault.l_users_games_date lugd
                  ON lugd.id = ch.element_id
          WHERE ch.data_type = 'user-game-date') res
    INTO @min_date;

   -- TRUNCATE gear.recent_changes;

    CREATE TEMPORARY TABLE temp_changed_to_aggregate
    SELECT data_type, element_id, data_status, stored_at
    FROM gear.recent_changes;

    CREATE INDEX index_temp_changed_to_aggregate_data_type_id
        ON temp_changed_to_aggregate (data_type, element_id);

    COMMIT;

    SELECT COUNT(*) AS cnt
    FROM temp_changed_to_aggregate
    INTO @were_changed;
-- _________________________________________________________________ --
    IF COALESCE(@were_changed, 0) > 0 THEN

        SELECT COUNT(*) AS cnt
        FROM gear.recent_changes
        WHERE data_type = 'user'
        INTO @users_were_changed;

        SELECT COUNT(*) AS cnt
        FROM gear.recent_changes
        WHERE data_type = 'game'
        INTO @games_were_changed;

        SELECT COUNT(*) AS cnt
        FROM gear.recent_changes
        WHERE data_type = 'user-game-date'
        INTO @ugd_were_changed;

        SELECT COUNT(*) AS cnt
        FROM gear.recent_changes
        WHERE data_type = 'payment'
        INTO @payments_were_changed;

        IF COALESCE(@payments_were_changed, 0) > 0 OR
           COALESCE(@ugd_were_changed, 0) > 0 OR
           COALESCE(@users_were_changed, 0) > 0 THEN

            CALL gear.aggregate_daily_users(@min_date);
            CALL gear.aggregate_daily_countries(@min_date);
        END IF;

        IF COALESCE(@ugd_were_changed, 0) > 0 OR
           COALESCE(@games_were_changed, 0) > 0 OR
           COALESCE(@users_were_changed, 0) > 0 THEN

            CALL gear.aggregate_daily_games(@min_date);
            CALL gear.aggregate_daily_game_types(@min_date);
        END IF;

        IF COALESCE(@ugd_were_changed, 0) > 0 THEN
            CALL gear.aggregate_daily_payments(@min_date);
        END IF;
    END IF;

    DROP TEMPORARY TABLE IF EXISTS temp_changed_to_aggregate;
END;

