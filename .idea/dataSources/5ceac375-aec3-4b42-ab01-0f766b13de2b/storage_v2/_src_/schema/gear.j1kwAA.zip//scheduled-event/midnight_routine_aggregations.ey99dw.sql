CREATE DEFINER = admin@`%` EVENT midnight_routine_aggregations ON SCHEDULE
    EVERY '24' HOUR
        STARTS '2023-12-01 00:00:01'
    ON COMPLETION PRESERVE
    ENABLE
    DO
    CALL gear.aggregate_total_payments();

