CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_daily_game_types(IN in_date date)
BEGIN
    -- call gear.aggregate_daily_game_types(NULL);

    SET @in_date = in_date;

    IF @in_date IS NULL THEN
        SELECT MIN(l.play_date) AS min_date
        FROM vault.l_users_games_date l
        INTO @in_date;

        SET @this_is_full_reload = 1;
    ELSE
        SET @this_is_full_reload = 0;
    END IF;

    DROP TABLE IF EXISTS gear.temp_daily_game_types_ugd;
    CREATE TABLE gear.temp_daily_game_types_ugd
    SELECT lugd.play_date               AS date,
           gt.id                        AS game_type_id,
           gt.name                      AS game_type,
           COUNT(DISTINCT g.id)         AS active_games,
           COUNT(DISTINCT u.id)         AS active_users,
           COUNT(DISTINCT u.country_id) AS active_countries,
           SUM(sugd.duration)           AS duration
    FROM vault.h_games g
        JOIN vault.h_game_types gt
            ON gt.id = g.type_id
        JOIN vault.l_users_games_date lugd
            ON g.id = lugd.game_id
        JOIN vault.h_users u
            ON u.id = lugd.user_id
        JOIN vault.s_users_games_date sugd
            ON lugd.id = sugd.l_users_games_date_id
    WHERE lugd.play_date >= @in_date
    GROUP BY lugd.play_date, gt.id;

-- _________________________________________________________________ --
    DROP TABLE IF EXISTS gear.swap_daily_game_types;
    CREATE TABLE gear.swap_daily_game_types LIKE bus.daily_game_types;

    INSERT INTO gear.swap_daily_game_types (date, game_type_id, game_type, active_games, active_users, active_countries, duration)
    SELECT dates.date,
           gt.id                      AS game_type_id,
           gt.name                    AS game_type,
           COUNT(DISTINCT g.id)       AS active_games,
           SUM(cugd.active_users)     AS active_users,
           SUM(cugd.active_countries) AS active_countries,
           SUM(cugd.duration)         AS duration
    FROM vault.calendar_dates dates
        INNER JOIN vault.h_games g
        JOIN vault.h_game_types gt
            ON gt.id = g.type_id
        LEFT JOIN gear.temp_daily_game_types_ugd AS cugd
            ON cugd.date = dates.date
            AND cugd.game_type_id = g.id
    WHERE dates.date >= @in_date
      AND dates.date <= CURRENT_DATE
    GROUP BY dates.date, gt.id, gt.name;

    IF @this_is_full_reload = 1 THEN
        START TRANSACTION;

        DROP TABLE IF EXISTS bus.daily_game_types;
        RENAME TABLE gear.swap_daily_game_types TO bus.daily_game_types;
        COMMIT;

    ELSE -- only new
        REPLACE INTO bus.daily_game_types (date, game_type_id, game_type, active_games, active_users, active_countries, duration)
        SELECT date, game_type_id, game_type, active_games, active_users, active_countries, duration
        FROM gear.swap_daily_game_types;

        DROP TABLE gear.swap_daily_game_types;
    END IF;

    CALL gear.aggregate_total_game_types();

END;

