CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_total_game_types()
BEGIN

    REPLACE INTO bus.total_game_types (game_type_id, game_type, games, dates, first_date, last_date, active_users, middle_users_daily, active_countries, middle_active_countries,
                                       duration,
                                       middle_duration_daily)
    SELECT hgt.id                                                         AS game_type_id,
           hgt.name                                                       AS game_type,
           COUNT(DISTINCT lugd.game_id)                                   AS games,
           COUNT(DISTINCT lugd.play_date)                                 AS dates,
           MIN(lugd.play_date)                                            AS first_date,
           MAX(lugd.play_date)                                            AS last_date,
           COUNT(DISTINCT lugd.user_id)                                   AS active_users,
           COUNT(DISTINCT lugd.user_id) / COUNT(DISTINCT lugd.play_date)  AS sumiddle_users_daily,
           COUNT(DISTINCT hu.country_id)                                  AS active_countries,
           COUNT(DISTINCT hu.country_id) / COUNT(DISTINCT lugd.play_date) AS middle_countriies_daily,
           SUM(duration)                                                  AS duration,
           SUM(duration) / COUNT(DISTINCT lugd.play_date)                 AS middle_duration_daily
    FROM vault.l_users_games_date lugd
        JOIN vault.h_games hg
            ON hg.id = lugd.game_id
        JOIN vault.h_game_types hgt
            ON hgt.id = hg.type_id
        JOIN vault.h_users hu
            ON hu.id = lugd.user_id
        JOIN vault.s_users_games_date sugd
            ON sugd.l_users_games_date_id = lugd.id
    GROUP BY lugd.game_id, hgt.name;

END;

