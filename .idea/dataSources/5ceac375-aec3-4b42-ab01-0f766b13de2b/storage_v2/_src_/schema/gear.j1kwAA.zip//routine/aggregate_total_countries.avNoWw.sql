CREATE
    DEFINER = admin@`%` PROCEDURE aggregate_total_countries()
BEGIN

    DROP TABLE IF EXISTS gear.temp_total_countries_games;
    CREATE TABLE gear.temp_total_countries_games
    SELECT c.id                         AS country_id,
           COUNT(DISTINCT lugd.game_id) AS active_games,
           COUNT(DISTINCT u.id)         AS active_users
    FROM vault.h_countries c
        JOIN vault.h_users u
            ON u.country_id = c.id
        JOIN vault.l_users_games_date lugd
            ON u.id = lugd.user_id
        JOIN vault.h_games g
            ON g.id = lugd.game_id
    GROUP BY c.id;

    DROP TABLE IF EXISTS gear.temp_total_countries;
    CREATE TABLE gear.temp_total_countries
    SELECT country_id,
           country,
           COUNT(DISTINCT date)                     AS dates,
           MIN(date)                                AS first_date,
           MAX(date)                                AS last_date,
           SUM(sign_ups)                            AS sign_ups,
           SUM(sign_ups) / COUNT(DISTINCT date)     AS middle_sign_ups_daily,
           SUM(transactions)                        AS transactions,
           SUM(transactions) / COUNT(DISTINCT date) AS middle_transactions_daily,
           SUM(deposit)                             AS deposit,
           SUM(deposit) / COUNT(DISTINCT date)      AS middle_deposit_daily,
           SUM(deposits)                            AS deposits,
           SUM(deposits) / COUNT(DISTINCT date)     AS middle_deposits_daily,
           SUM(withdrawal)                          AS withdrawal,
           SUM(withdrawal) / COUNT(DISTINCT date)   AS middle_withdrawal_daily,
           SUM(withdrawals)                         AS withdrawals,
           SUM(withdrawals) / COUNT(DISTINCT date)  AS middle_withdrawals_daily,
           SUM(duration)                            AS duration,
           SUM(duration) / COUNT(DISTINCT date)     AS middle_duration_daily
    FROM bus.daily_countries AS dc
    WHERE country IS NOT NULL
    GROUP BY country, country_id;

    REPLACE INTO bus.total_countries (country_id, country, dates, first_date, last_date, active_users, middle_users_daily, active_games, middle_games_daily, sign_ups,
                                      middle_sign_ups_daily,
                                      transactions, middle_transactions_daily, deposit, middle_deposit_daily, deposits, middle_deposits_daily, withdrawal, middle_withdrawal_daily,
                                      withdrawals, middle_withdrawals_daily, duration, middle_duration_daily)
    SELECT dc.country_id,
           dc.country,
           dc.dates,
           dc.first_date,
           dc.last_date,
           g.active_users,
           g.active_users / dc.dates AS middle_users_daily,
           g.active_games,
           g.active_games / dc.dates AS middle_games_daily,
           dc.sign_ups,
           dc.middle_sign_ups_daily,
           dc.transactions,
           dc.middle_transactions_daily,
           dc.deposit,
           dc.middle_deposit_daily,
           dc.deposits,
           dc.middle_deposits_daily,
           dc.withdrawal,
           dc.middle_withdrawal_daily,
           dc.withdrawals,
           dc.middle_withdrawals_daily,
           dc.duration,
           dc.middle_duration_daily
    FROM gear.temp_total_countries AS dc
        JOIN gear.temp_total_countries_games AS g
            ON g.country_id = dc.country_id;

END;

