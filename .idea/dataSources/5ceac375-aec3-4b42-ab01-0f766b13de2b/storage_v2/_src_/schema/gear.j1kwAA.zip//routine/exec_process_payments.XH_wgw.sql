CREATE
    DEFINER = admin@`%` PROCEDURE exec_process_payments()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS temp_in_payments;

    SET @processed_payments = 0;

    CREATE TEMPORARY TABLE temp_in_payments
    SELECT DISTINCT transactionid                            AS transaction_id,
                    userid                                   AS user_id,
                    CAST(amount AS dec(13, 2))               AS amount,
                    STR_TO_DATE(transactiondate, '%d/%m/%Y') AS transaction_date,
                    type,
                    max(imported_at) as imported_at
    FROM staging.payments
    WHERE userid <> 'UserID'
    GROUP BY transactionid,
             userid,
             CAST(amount AS dec(13, 2)),
             STR_TO_DATE(transactiondate, '%d/%m/%Y'),
             type;

    CREATE INDEX index_temp_in_payments_transaction_id
        ON temp_in_payments (transaction_id);

    DROP TEMPORARY TABLE IF EXISTS temp_recently_changed;
    CREATE TEMPORARY TABLE temp_recently_changed LIKE gear.recent_changes;

    START TRANSACTION;

-- payments
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'payment', 'changed', new.transaction_id
    FROM temp_in_payments AS new
        JOIN vault.payments old
            ON old.transaction_id = new.transaction_id
    WHERE old.amount <> new.amount OR
          old.type <> new.type;

    UPDATE vault.payments old
        JOIN temp_recently_changed AS r_ch
        ON r_ch.element_id = old.transaction_id
        JOIN temp_in_payments new
        ON old.transaction_id = new.transaction_id
    SET old.amount = new.amount,
        old.type   = new.type
    WHERE old.amount <> new.amount OR
          old.type <> new.type;
    SET @processed_payments = @processed_payments + ROW_COUNT();

-- ins
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'payment', 'new', new.transaction_id
    FROM temp_in_payments AS new
        LEFT JOIN vault.payments old
            ON old.transaction_id = new.transaction_id
    WHERE old.transaction_id IS NULL;

    INSERT INTO vault.payments(transaction_id, user_id, amount, transaction_date, type)
    SELECT transaction_id, user_id, amount, transaction_date, type
    FROM temp_recently_changed AS r_ch
        JOIN temp_in_payments new
            ON r_ch.data_status = 'new'
            AND r_ch.element_id = new.transaction_id;
    SET @processed_payments = @processed_payments + ROW_COUNT();
--
    INSERT INTO bulk.processed_payments(transaction_id, user_id, amount, transaction_date, type, imported_at)
    SELECT transaction_id, user_id, amount, transaction_date, type, imported_at
    FROM temp_in_payments;

    TRUNCATE TABLE staging.payments;
    COMMIT;

    SELECT MAX(imported_at) AS imported_at
    FROM temp_in_payments tig
    INTO @imported_at;

    DROP TEMPORARY TABLE temp_in_payments;

    INSERT gear.process_staging_logs(table_name, processed_count, imported_at)
        VALUE ('payments', @processed_payments, @imported_at);


    INSERT gear.recent_changes(data_type, element_id, data_status)
    SELECT data_type, element_id, data_status
    FROM temp_recently_changed;

    DROP TEMPORARY TABLE temp_recently_changed;

END;

