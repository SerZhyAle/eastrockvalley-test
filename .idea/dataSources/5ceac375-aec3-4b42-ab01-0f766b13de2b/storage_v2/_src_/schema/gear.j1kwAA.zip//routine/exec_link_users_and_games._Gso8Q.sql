CREATE
    DEFINER = admin@`%` PROCEDURE exec_link_users_and_games()
BEGIN

    INSERT INTO vault.l_users_games_date(user_id, game_id, play_date)
    SELECT new.user_id,
           new.game_id,
           new.play_date
    FROM gear.temp_games new
        LEFT JOIN vault.l_users_games_date old
            ON old.user_id = new.user_id
            AND old.game_id = new.game_id
            AND old.play_date = new.play_date
    WHERE old.id IS NULL;

    DROP TEMPORARY TABLE IF EXISTS temp_recently_changed;
    CREATE TEMPORARY TABLE temp_recently_changed LIKE gear.recent_changes;

    START TRANSACTION ;

    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'user-game-date', 'changed', old.id
    FROM vault.l_users_games_date old
        JOIN temp_games new
            ON old.user_id = new.user_id
            AND old.game_id = new.game_id
            AND old.play_date = new.play_date
        JOIN vault.s_users_games_date s_upd
            ON s_upd.l_users_games_date_id = old.id
    WHERE s_upd.duration <> new.duration;

    UPDATE vault.s_users_games_date old
        JOIN temp_recently_changed r_ch
        ON old.l_users_games_date_id = r_ch.element_id
        JOIN vault.l_users_games_date AS l
        ON l.id = r_ch.element_id
        JOIN temp_games new
        ON l.user_id = new.user_id
            AND l.game_id = new.game_id
            AND l.play_date = new.play_date
    SET old.duration = new.duration
    WHERE old.duration <> new.duration;

-- ins
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'user-game-date', 'new', old.id
    FROM vault.l_users_games_date old
        JOIN temp_games new
            ON old.user_id = new.user_id
            AND old.game_id = new.game_id
            AND old.play_date = new.play_date
        LEFT JOIN vault.s_users_games_date AS s_upd
            ON s_upd.l_users_games_date_id = old.id
    WHERE s_upd.l_users_games_date_id IS NULL;

    INSERT INTO vault.s_users_games_date(l_users_games_date_id, duration)
    SELECT l.id,
           new.duration
    FROM temp_recently_changed AS r_ch
        JOIN vault.l_users_games_date AS l
            ON r_ch.data_status = 'new'
            AND l.id = r_ch.element_id
        JOIN temp_games new
            ON l.user_id = new.user_id
            AND l.game_id = new.game_id
            AND l.play_date = new.play_date;
    COMMIT;

    TRUNCATE gear.temp_games;

    INSERT gear.recent_changes(data_type, element_id, data_status)
    SELECT data_type, element_id, data_status
    FROM temp_recently_changed;

    DROP TEMPORARY TABLE temp_recently_changed;

END;

