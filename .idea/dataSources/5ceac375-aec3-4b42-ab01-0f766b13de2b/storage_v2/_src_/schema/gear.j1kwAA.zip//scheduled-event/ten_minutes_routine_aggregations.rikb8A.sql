CREATE DEFINER = admin@`%` EVENT ten_minutes_routine_aggregations ON SCHEDULE
    EVERY '10' MINUTE
        STARTS '2023-12-01 00:05:01'
    ON COMPLETION PRESERVE
    ENABLE
    DO
    CALL gear.calc_aggregations();

