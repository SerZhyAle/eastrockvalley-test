CREATE
    DEFINER = admin@`%` PROCEDURE exec_process_games()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS temp_in_games;

    SET @processed_games = 0;

    CREATE TEMPORARY TABLE temp_in_games
    SELECT DISTINCT gameid                            AS game_id,
                    userid                            AS user_id,
                    gametype                          AS game_type,
                    STR_TO_DATE(playdate, '%d/%m/%Y') AS play_date,
                    duration                          AS duration,
                    MAX(imported_at)                  AS imported_at
    FROM staging.games
    WHERE userid <> 'UserID'
    GROUP BY gameid,
             userid,
             gametype,
             STR_TO_DATE(playdate, '%d/%m/%Y'),
             duration;

    CREATE INDEX index_temp_in_games_game_id
        ON temp_in_games (game_id);

    INSERT INTO vault.h_game_types(name)
    SELECT DISTINCT game_type
    FROM temp_in_games new
        LEFT JOIN vault.h_game_types old
            ON old.name = new.game_type
    WHERE old.name IS NULL;

    DROP TEMPORARY TABLE IF EXISTS temp_recently_changed;
    CREATE TEMPORARY TABLE temp_recently_changed LIKE gear.recent_changes;

-- _________________________________________________________________ --
    START TRANSACTION;

-- games
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'game', 'changed', new.game_id
    FROM temp_in_games AS new
        JOIN vault.h_games old
            ON old.id = new.game_id
        JOIN vault.h_game_types AS game_types
            ON game_types.name = new.game_type
    WHERE (old.type_id <> game_types.id);

    UPDATE vault.h_games old
        JOIN temp_recently_changed AS r_ch
        ON old.id = r_ch.element_id
        JOIN temp_in_games AS new
        ON old.id = new.game_id
        JOIN vault.h_game_types AS game_types
        ON game_types.name = new.game_type
    SET old.type_id = game_types.id
    WHERE (old.type_id <> game_types.id);
    SET @processed_games = @processed_games + ROW_COUNT();

-- ins
    INSERT INTO temp_recently_changed(data_type, data_status, element_id)
    SELECT 'game', 'new', new.game_id
    FROM temp_in_games AS new
        LEFT JOIN vault.h_games AS old
            ON old.id = new.game_id
    WHERE old.id IS NULL;

    INSERT INTO vault.h_games(id, type_id)
    SELECT new.game_id,
           game_types.id AS type_id
    FROM temp_recently_changed AS r_ch
        JOIN temp_in_games AS new
            ON r_ch.data_status = 'new'
            AND new.game_id = r_ch.element_id
        JOIN vault.h_game_types AS game_types
            ON game_types.name = new.game_type;
    SET @processed_games = @processed_games + ROW_COUNT();

    INSERT INTO gear.temp_games(game_id, user_id, game_type, play_date, duration, imported_at)
    SELECT game_id, user_id, game_type, play_date, duration, imported_at
    FROM temp_in_games;

--
    INSERT INTO bulk.processed_games(game_id, user_id, game_type, play_date, duration, imported_at)
    SELECT game_id, user_id, game_type, play_date, duration, imported_at
    FROM temp_in_games;

    TRUNCATE TABLE staging.games;
    COMMIT;

    SELECT MAX(imported_at) AS imported_at
    FROM temp_in_games tig
    INTO @imported_at;

    DROP TEMPORARY TABLE temp_in_games;

    INSERT gear.process_staging_logs(table_name, processed_count, imported_at)
        VALUE ('games', @processed_games, @imported_at);

    INSERT gear.recent_changes(data_type, element_id, data_status)
    SELECT data_type, element_id, data_status
    FROM temp_recently_changed;

    DROP TEMPORARY TABLE temp_recently_changed;

END;

